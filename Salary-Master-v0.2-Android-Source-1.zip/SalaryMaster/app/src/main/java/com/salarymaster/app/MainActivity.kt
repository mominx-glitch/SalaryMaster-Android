package com.salarymaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF151F31)
private val Gold = Color(0xFFF3B94F)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SalaryMasterApp() }
    }
}

@Composable
fun SalaryMasterApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                val items = listOf(Triple("Home", Icons.Default.Home, "Home"), Triple("Staff", Icons.Default.Groups, "Staff"), Triple("Payroll", Icons.Default.Payments, "Payroll"), Triple("More", Icons.Default.Menu, "More"))
                items.forEach { (label, icon, route) ->
                    NavigationBarItem(selected = selected == route, onClick = { selected = route }, icon = { Icon(icon, null) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, indicatorColor = Color(0xFF29364A), selectedTextColor = Gold, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            AnimatedContent(targetState = selected, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "screen-transition", modifier = Modifier.padding(padding)) { page ->
                when (page) {
                    "Staff" -> PlaceholderScreen("Staff Management", "Add employees, set salary and manage staff profiles.", Icons.Default.Groups)
                    "Payroll" -> PlaceholderScreen("Payroll", "Prepare monthly payroll, record payments and track dues.", Icons.Default.Payments)
                    "More" -> PlaceholderScreen("More Tools", "Attendance, reports, salary slips and settings.", Icons.Default.Apps)
                    else -> DashboardScreen()
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(top = 26.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SALARY MASTER", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Good morning, Owner", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Here’s your payroll overview", color = Muted, fontSize = 13.sp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) { Icon(Icons.Default.NotificationsNone, null, tint = Gold) }
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFF243B5A), Color(0xFF111C2E)))).padding(22.dp)) {
                    Text("TOTAL MONTHLY PAYROLL", color = Color(0xFFCFD8E5), fontSize = 11.sp, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("৳ 0.00", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null, tint = Gold, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(7.dp)); Text("November 2026", color = Color(0xFFCFD8E5), fontSize = 13.sp) }
                }
            }
        }
        item { Text("Overview", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Total Staff", "0", Icons.Default.Groups, Modifier.weight(1f))
                MetricCard("Paid", "৳ 0", Icons.Default.CheckCircle, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Due Salary", "৳ 0", Icons.Default.PendingActions, Modifier.weight(1f))
                MetricCard("Present Today", "0", Icons.Default.HowToReg, Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Quick actions", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Text("Coming next", color = Gold, fontSize = 11.sp) }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("Add Staff", Icons.Default.PersonAdd, Modifier.weight(1f))
                QuickAction("Pay Salary", Icons.Default.Payments, Modifier.weight(1f))
                QuickAction("Attendance", Icons.Default.FactCheck, Modifier.weight(1f))
            }
        }
        item { Text("Recent activity", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, null, tint = Gold)
                    Spacer(Modifier.width(12.dp))
                    Column { Text("No activity yet", color = Color.White, fontWeight = FontWeight.Medium); Text("Staff and salary activity will appear here.", color = Muted, fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(21.dp))
            Spacer(Modifier.height(14.dp))
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickAction(title: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun PlaceholderScreen(title: String, description: String, icon: ImageVector) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(76.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Gold, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.height(18.dp))
        Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(description, color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(18.dp))
        Text("Module planned for the next development milestone", color = Gold, fontSize = 12.sp)
    }
}
