# Salary Master — Firebase data model

All money values are stored as integer paisa (BDT × 100), never floating-point values.

## Collections

- `users/{uid}` — minimal user profile; created/updated only by trusted backend code.
- `organizations/{orgId}` — one employer/company workspace.
- `organizations/{orgId}/members/{uid}` — `{ role: 'owner'|'staff', active: Boolean, staffId: String|null, email: String }`.
- `organizations/{orgId}/staff/{staffId}` — `{ name, email, phone, monthlySalaryPaisa, joiningDate, active, createdAt }`.
- `organizations/{orgId}/payroll/{payrollId}` — `{ staffUid, staffId, year, month, baseSalaryPaisa, overtimePaisa, bonusPaisa, deductionPaisa, advancePaisa, netSalaryPaisa, paidPaisa, duePaisa, status, createdAt, updatedAt }`.
- `organizations/{orgId}/attendance/{recordId}` — `{ staffUid, staffId, date, status, note, createdAt }`.
- `organizations/{orgId}/payments/{paymentId}` — `{ staffUid, staffId, payrollId, amountPaisa, paidAt, method, note, createdByUid }`.
- `organizations/{orgId}/invites/{inviteId}` — `{ email, staffId, status: 'pending'|'accepted'|'revoked', createdAt }`.

## Authentication and invitation flow

1. Owner signs in with Google. A trusted backend creates the organization and assigns the owner role. Never allow the Android client to assign itself the owner role.
2. Owner creates a staff profile and invite for a normalized email address.
3. Staff signs in with Google. A trusted backend verifies the Google-authenticated email matches a pending invite, then creates the staff membership linked to that staff record.
4. Staff can read only their own staff record, payroll, attendance, and payment records. Owner can manage the organization's records.
5. Revoking an invite or deactivating membership must immediately block access through Security Rules.

## Important implementation notes

- Deploy `firestore.rules` before storing real salary information. Test rules with the Firebase Emulator Suite.
- Membership documents and role fields must be written by trusted backend code (for example, callable Cloud Functions using the Admin SDK), not directly by the Android app.
- Add App Check and audit logging before production use.
- Payroll totals should be calculated and validated in trusted backend code or transaction-safe application logic. Never trust a client-supplied `netSalaryPaisa` or `paidPaisa` value.
